<section>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <h5 class="my-4"><?= isset($title) ? $title : '' ?></h5>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6">
            <div class="alert alert-primary" role="alert">
                Status : <b><?= $transaksi_langganan['status'] ?></b>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-3">
                        <span>
                            <?= $transaksi_langganan['kode']; ?>
                        </span>
                        <span>
                            <?= date('d-m-Y H:i:s', strtotime($transaksi_langganan['created_at'])) ?>
                        </span>
                    </div>
                    <table class="table w-100">
                        <thead>
                            <tr>
                                <th class="text-primary-emphasis">Paket Langganan</th>
                                <th class="text-primary-emphasis">Biaya</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <h5><?= $transaksi_langganan['nama_paket'] ?></h5>
                                    <?= $transaksi_langganan['poin'] ?> Poin <br>
                                    <span class="text-secondary">
                                        <?= $transaksi_langganan['deskripsi'] ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($transaksi_langganan['harga_normal'] > $transaksi_langganan['harga_promo']) : ?>
                                    <small class="text-decoration-line-through text-secondary">
                                        Rp <?= number_format($transaksi_langganan['harga_normal'], 0, ',', '.') ?>
                                    </small> <br>
                                    <?php endif; ?>
                                    Rp <?= number_format($transaksi_langganan['harga_promo'], 0, ',', '.') ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-end">Total</td>
                                <td>
                                    <h5 class="fw-600">Rp <?= number_format($transaksi_langganan['harga_promo'], 0, ',', '.') ?></h5>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <a href="<?= $transaksi_langganan['invoice_url'] ?>" target="_blank" class="btn btn-primary float-end px-4">Bayar Sekarang</a>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
