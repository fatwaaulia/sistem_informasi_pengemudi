<?php

namespace App\Models;

use CodeIgniter\Model;

class TransaksiLangganan extends Model
{
    protected $table         = 'transaksi_langganan';
    protected $protectFields = false;
    protected $useTimestamps = true;
}
