<?php

namespace App\Models;

use CodeIgniter\Model;

class RiwayatPencarian extends Model
{
    protected $table         = 'riwayat_pencarian';
    protected $protectFields = false;
    protected $useTimestamps = true;
}
