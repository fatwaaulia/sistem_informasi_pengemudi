<?php

namespace App\Models;

use CodeIgniter\Model;

class Temuan extends Model
{
    protected $table         = 'temuan';
    protected $protectFields = false;
    protected $useTimestamps = true;
}
