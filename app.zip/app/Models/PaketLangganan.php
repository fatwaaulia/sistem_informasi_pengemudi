<?php

namespace App\Models;

use CodeIgniter\Model;

class PaketLangganan extends Model
{
    protected $table         = 'paket_langganan';
    protected $protectFields = false;
    protected $useTimestamps = true;
}
