<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->set404Override(
    function() {
        $data['title'] = '404';
        $data['content'] = view('errors/page_404');

        $uri_1 = service('uri')->getSegment(1);
        $role = model('Role')->findColumn('slug');
        if (session()->isLogin === true && in_array($uri_1, $role)) {
            $data['sidebar'] = view('dashboard/sidebar');
            return view('dashboard/header', $data);
        } else {
            $data['navbar'] = view('landingpage/navbar');
            $data['footer'] = view('landingpage/footer');
            return view('landingpage/header', $data);
        }
    }
);

/*--------------------------------------------------------------
  # Landing Page
--------------------------------------------------------------*/
$routes->get('/', 'Landingpage::beranda');

/*--------------------------------------------------------------
  # API
--------------------------------------------------------------*/
$routes->post('webhook/xendit', function() {
    $json = file_get_contents('php://input');
    $response = json_decode($json, true);

    if ($response['id']) {
        $cek_transaksi = model('TransaksiLangganan')->where('invoice_id', $response['id'])->first();
        if ($cek_transaksi) {

            $api_key = 'xnd_development_PpGuPzQwPPOWAfP93FYXLZx9eR5oGYqijUFBfXGeuSS8zotffTFIiOwaJwE5vZ3:';
            $api_key_base64 = base64_encode($api_key);

            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => 'https://api.xendit.co/v2/invoices/' . $response['id'],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'GET',
                CURLOPT_POSTFIELDS => '',
                CURLOPT_HTTPHEADER => array(
                    'Content-Type: application/json',
                    'Authorization: Basic ' . $api_key_base64,
                ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);

            $response = json_decode($response, true);

            print_r($response);

            $status = 'Menunggu Pembayaran';
            if ($response['status'] == 'PENDING') {
                $status = 'Menunggu Pembayaran';
            } elseif ($response['status'] == 'PAID') {
                $status = 'Lunas';
            } elseif ($response['status'] == 'SETTLED') {
                $status = 'Lunas';
            } elseif ($response['status'] == 'EXPIRED') {
                $status = 'Kedaluwarsa';
            }

            $data = [
                'status' => $status,
                'invoice_status' => $response['status'],
                'paid_at' => $response['paid_at'],
            ];

            model('TransaksiLangganan')->update($cek_transaksi['id'], $data);

            header('Content-Type: application/json; charset=utf-8');
            $html = array();
            $html['status'] = true;
            $html['code'] = 200;
            $html['data'] = json_encode($json, true);
            $html['msg'] = "Webhook xendit was successfully";
            echo json_encode($html, true);
        } else {
            header('Content-Type: application/json; charset=utf-8');
            $html = array();
            $html['status'] = false;
            $html['code'] = 200;
            $html['data'] = json_encode($json, true);
            $html['msg'] = "Transaction not found";
            echo json_encode($html, true);
        }
    } else {
        header('Content-Type: application/json; charset=utf-8');
        $html = array();
        $html['status'] = false;
        $html['code'] = 200;
        $html['data'] = json_encode($json, true);
        $html['msg'] = "Webhook xendit was unsuccessfully";
        echo json_encode($html, true);
    }
});

/*--------------------------------------------------------------
  # Autentikasi
--------------------------------------------------------------*/
// login
$routes->get('login', 'Auth::login');
$routes->post('login-process', 'Auth::loginProcess');
$routes->get('logout', 'Auth::logout');
// register
$routes->get('register', 'Auth::register');
$routes->post('register-process', 'Auth::registerProcess');
// email layout
$routes->get('email-layout', 'AppSettings::emailLayout');

/*--------------------------------------------------------------
  # Dashboard & Profil
--------------------------------------------------------------*/
$user_session = model('Users')->where('id', session()->get('id_user'))->first();
if ($user_session) {
    $user_role = model('Role')->where('id', $user_session['id_role'])->first()['slug'];
    $routes->get($user_role . '/dashboard', 'Dashboard::dashboard', ['filter' => 'EnsureIsLogin']);
    $routes->group($user_role . '/profile', ['filter' => 'EnsureIsLogin'], static function ($routes) {
        $routes->get('/', 'Users::profile');
        $routes->post('update', 'Users::updateProfile');
        $routes->post('update/password', 'Users::updatePassword');
        $routes->post('delete/image', 'Users::deleteProfilePhoto');
    });
}

/*--------------------------------------------------------------
  # Superadmin
--------------------------------------------------------------*/
$routes->group('superadmin/app-settings', ['filter' => 'EnsureSuperAdmin'], static function ($routes) {
    $routes->get('/', 'AppSettings::index');
    $routes->get('menu', 'AppSettings::menu');
    $routes->post('update/(:segment)', 'AppSettings::update/$1');
    $routes->post('send-email', 'AppSettings::sendEmail');
});
$routes->group('superadmin/users', ['filter' => 'EnsureSuperAdmin'], static function ($routes) {
    $routes->get('get-data', 'Users::getData');
    $routes->get('/', 'Users::index');
    $routes->get('new', 'Users::new');
    $routes->post('create', 'Users::create');
    $routes->get('edit/(:segment)', 'Users::edit/$1');
    $routes->post('update/(:segment)', 'Users::update/$1');
    $routes->post('delete/(:segment)', 'Users::delete/$1');
    $routes->post('delete/image/(:segment)', 'Users::deleteImg/$1');
});
$routes->group('superadmin/pengajuan-perusahaan', ['filter' => 'EnsureSuperAdmin'], static function ($routes) {
    $routes->get('get-data', 'PengajuanPerusahaan::getData');
    $routes->get('/', 'PengajuanPerusahaan::index');
    $routes->get('edit/(:segment)', 'PengajuanPerusahaan::edit/$1');
    $routes->post('update/(:segment)', 'PengajuanPerusahaan::update/$1');
    $routes->post('delete/(:segment)', 'PengajuanPerusahaan::delete/$1');
});
$routes->group('superadmin/perusahaan', ['filter' => 'EnsureSuperAdmin'], static function ($routes) {
    $routes->get('get-data', 'PengajuanPerusahaan::getDataPerusahaanAktif');
    $routes->get('/', 'PengajuanPerusahaan::perusahaanAktif');
    $routes->get('detail/(:segment)', 'PengajuanPerusahaan::detailPerusahaanAktif/$1');
});
$routes->group('superadmin/paket-langganan', ['filter' => 'EnsureSuperAdmin'], static function ($routes) {
    $routes->get('get-data', 'PaketLangganan::getData');
    $routes->get('/', 'PaketLangganan::index');
    $routes->get('new', 'PaketLangganan::new');
    $routes->post('create', 'PaketLangganan::create');
    $routes->get('edit/(:segment)', 'PaketLangganan::edit/$1');
    $routes->post('update/(:segment)', 'PaketLangganan::update/$1');
    $routes->post('delete/(:segment)', 'PaketLangganan::delete/$1');
});

/*--------------------------------------------------------------
  # Admin
--------------------------------------------------------------*/
$routes->group('admin/pengajuan-perusahaan', ['filter' => 'EnsureAdmin'], static function ($routes) {
    $routes->get('get-data', 'PengajuanPerusahaan::getData');
    $routes->get('/', 'PengajuanPerusahaan::index');
    $routes->get('edit/(:segment)', 'PengajuanPerusahaan::edit/$1');
    $routes->post('update/(:segment)', 'PengajuanPerusahaan::update/$1');
    $routes->post('delete/(:segment)', 'PengajuanPerusahaan::delete/$1');
});
$routes->group('admin/perusahaan', ['filter' => 'EnsureAdmin'], static function ($routes) {
    $routes->get('get-data', 'PengajuanPerusahaan::getDataPerusahaanAktif');
    $routes->get('/', 'PengajuanPerusahaan::perusahaanAktif');
    $routes->get('detail/(:segment)', 'PengajuanPerusahaan::detailPerusahaanAktif/$1');
});
$routes->group('admin/paket-langganan', ['filter' => 'EnsureAdmin'], static function ($routes) {
    $routes->get('get-data', 'PaketLangganan::getData');
    $routes->get('/', 'PaketLangganan::index');
    $routes->get('new', 'PaketLangganan::new');
    $routes->post('create', 'PaketLangganan::create');
    $routes->get('edit/(:segment)', 'PaketLangganan::edit/$1');
    $routes->post('update/(:segment)', 'PaketLangganan::update/$1');
    $routes->post('delete/(:segment)', 'PaketLangganan::delete/$1');
});

/*--------------------------------------------------------------
  # Perusahaan
--------------------------------------------------------------*/
$routes->group('perusahaan/pengajuan-perusahaan', ['filter' => 'EnsurePerusahaan'], static function ($routes) {
    $routes->get('/', 'PengajuanPerusahaan::kirimPengajuan');
    $routes->post('update', 'PengajuanPerusahaan::prosesKirimPengajuan');
});
$routes->group('perusahaan/lapor-temuan', ['filter' => 'EnsurePerusahaan'], static function ($routes) {
    $routes->get('get-data', 'Temuan::getData');
    $routes->get('/', 'Temuan::index');
    $routes->get('new', 'Temuan::new');
    $routes->post('create', 'Temuan::create');
    $routes->get('edit/(:segment)', 'Temuan::edit/$1');
    $routes->post('update/(:segment)', 'Temuan::update/$1');
    $routes->post('delete/(:segment)', 'Temuan::delete/$1');
});
$routes->group('perusahaan/cari-temuan', ['filter' => 'EnsurePerusahaan'], static function ($routes) {
    $routes->get('/', 'Temuan::cariTemuan');
});
$routes->group('perusahaan/riwayat-pencarian', ['filter' => 'EnsurePerusahaan'], static function ($routes) {
    $routes->get('get-data', 'RiwayatPencarian::getData');
    $routes->get('/', 'RiwayatPencarian::index');
});
$routes->group('perusahaan/berlangganan', ['filter' => 'EnsurePerusahaan'], static function ($routes) {
    $routes->get('get-data', 'Berlangganan::getData');
    $routes->get('/', 'Berlangganan::index');
    $routes->get('new', 'Berlangganan::new');
    $routes->post('create', 'Berlangganan::create');
    $routes->get('edit/(:segment)', 'Berlangganan::edit/$1');
    $routes->post('update/(:segment)', 'Berlangganan::update/$1');
    $routes->post('delete/(:segment)', 'Berlangganan::delete/$1');
});
$routes->group('perusahaan/transaksi-langganan', ['filter' => 'EnsurePerusahaan'], static function ($routes) {
    $routes->get('get-data', 'TransaksiLangganan::getData');
    $routes->get('/', 'TransaksiLangganan::index');
    $routes->post('create', 'TransaksiLangganan::create');
    $routes->get('detail', 'TransaksiLangganan::detail');
});